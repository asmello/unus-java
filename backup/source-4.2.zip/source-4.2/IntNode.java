public final class IntNode {
	public int value;
	public IntNode next;
	
	IntNode(int value) { this.value = value; }
}
